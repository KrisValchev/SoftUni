﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PlayersAndMonsters
{
    public class Elf:Hero
    {
        public Elf(string name,int level) : base(name, level)
        {
            
        }
    }
}
