﻿namespace AuthorProblem
{
     class StartUp
    {
        static void Main(string[] args)
        {
            Tracker tracker=new Tracker();
            tracker.PrintMethodsByAuthor();
        }
    }
}