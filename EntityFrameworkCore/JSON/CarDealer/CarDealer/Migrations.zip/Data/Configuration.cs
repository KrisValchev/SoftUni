﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=KVALCHEV\SQLEXPRESS;Database=CarDealer;Integrated Security=True;";
    }
}
