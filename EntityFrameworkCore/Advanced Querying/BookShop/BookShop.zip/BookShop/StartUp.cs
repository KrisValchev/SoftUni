﻿namespace BookShop
{
	using BookShop.Models.Enums;
	using Data;
    using Initializer;
	using System.Text;

	public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            Console.WriteLine(GetBooksByAgeRestriction(db,"miNor"));
        }
		public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
           if(Enum.TryParse(command,true,out AgeRestriction ageRestriction))
            {
            return string.Join(Environment.NewLine, context.Books.OrderBy(b => b.Title).Where(b => b.AgeRestriction == ageRestriction).Select(b => $"{b.Title}").ToList());
            }
            else
            {
                return string.Empty;
            }
        }

	}
}


